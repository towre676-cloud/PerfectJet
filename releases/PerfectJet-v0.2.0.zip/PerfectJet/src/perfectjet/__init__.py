"""PerfectJet: exact computational kernels and a status-aware research atlas."""
__version__ = "0.2.0"
